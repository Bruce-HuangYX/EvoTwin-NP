# Indoor Air Example
Put CSV files under `data/` and set paths in `config.yaml`.
