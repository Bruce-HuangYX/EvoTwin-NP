# Misc utilities (placeholder)
