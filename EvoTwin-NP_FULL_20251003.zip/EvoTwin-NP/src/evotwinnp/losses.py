# Losses and NP constraints (placeholder)
