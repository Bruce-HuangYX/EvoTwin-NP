#!/usr/bin/env bash
python -m evotwinnp.cli evo --config examples/indoor_air/config.yaml
