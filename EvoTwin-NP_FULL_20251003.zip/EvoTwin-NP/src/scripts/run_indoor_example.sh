#!/usr/bin/env bash
python -m evotwinnp.cli train --config examples/indoor_air/config.yaml
