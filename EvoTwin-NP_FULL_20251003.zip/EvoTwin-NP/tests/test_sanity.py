def test_import():
    import evotwinnp
